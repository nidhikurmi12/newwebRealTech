import React from "react";

const TenantVerify = () => {
  return <div>Tenant verification</div>;
};

export default TenantVerify;
