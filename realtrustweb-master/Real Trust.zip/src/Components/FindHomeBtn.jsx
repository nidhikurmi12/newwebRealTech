import React from "react";
import { FaSearch } from "react-icons/fa";

const FindHomeButton = () => {
  return (
    // <button className="md:flex hidden absolute sm:text-6xl text-5xl bottom-0 left-[4%] w-fit bg-gray-800 md:left-[10.4%] z-30 items-center  text-white font-bold ">
    //   <FaSearch className="p-4 bg-gray-900" />

    //   {/* Text */}
    //   <span className="ml-2 font-semibold text-white text-2xl sm:text-3xl pl-4 pr-6">
    //     Find Your Home
    //   </span>
    // </button>
    <span></span>
  );
};

export default FindHomeButton;
